package com.crm.subscription.infrastructure.emailService;

public class email {
}
