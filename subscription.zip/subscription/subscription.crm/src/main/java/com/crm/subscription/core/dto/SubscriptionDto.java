package com.crm.subscription.core.dto;

public class SubscriptionDto {
}
