package com.crm.subscription.infrastructure.domain.sql.model;

public class SubscriptionEntity {
}
