package com.crm.subscription.core.resp;

public class SubscriptionResp {
}
