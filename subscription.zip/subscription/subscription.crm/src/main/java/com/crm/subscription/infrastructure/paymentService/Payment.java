package com.crm.subscription.infrastructure.paymentService;

public class Payment{
}
