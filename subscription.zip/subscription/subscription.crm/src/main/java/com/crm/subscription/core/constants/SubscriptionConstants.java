package com.crm.subscription.core.constants;

public class SubscriptionConstants {
}
