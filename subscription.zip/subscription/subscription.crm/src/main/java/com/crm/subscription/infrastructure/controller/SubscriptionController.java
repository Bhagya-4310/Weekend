package com.crm.subscription.infrastructure.controller;

public class SubscriptionController {
}
