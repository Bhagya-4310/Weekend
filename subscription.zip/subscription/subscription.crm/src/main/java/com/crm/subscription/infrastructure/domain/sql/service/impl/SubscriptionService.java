package com.crm.subscription.infrastructure.domain.sql.service.impl;

public class SubscriptionService {



}