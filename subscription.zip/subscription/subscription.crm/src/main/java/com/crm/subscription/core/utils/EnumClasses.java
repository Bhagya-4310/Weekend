package com.crm.subscription.core.utils;

public class EnumClasses {
}
