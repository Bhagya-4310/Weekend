package com.crm.subscription.core.req;

public class SubscriptionReq {
}
