package com.crm.subscription.infrastructure.domain.sql.service.handler;

public class Mapper {
}
